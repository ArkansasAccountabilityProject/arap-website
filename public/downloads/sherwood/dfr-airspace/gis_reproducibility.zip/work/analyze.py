import sys
# Requires shapely, pyproj, geopandas, matplotlib, reportlab and requests.
import json,pathlib,datetime,csv
import geopandas as gp
from shapely.geometry import shape,mapping,Point
from shapely.ops import unary_union,transform
from shapely import make_valid
from pyproj import Transformer,Geod
W=pathlib.Path('work');O=pathlib.Path('outputs')
def load(n):return json.loads((W/n).read_text(encoding='utf-8-sig'))
proj=Transformer.from_crs(4326,5070,always_xy=True).transform
inv=Transformer.from_crs(5070,4326,always_xy=True).transform
def geom(f):return make_valid(transform(proj,shape(f['geometry'])))
city=unary_union([geom(f) for f in load('city.geojson')['features']])
water=gp.read_file('zip://'+str((W/'water.zip').resolve())).to_crs(5070)
water=unary_union([g.intersection(city) for g in water.geometry if g.intersects(city)])
land=city.difference(water)
uas_all=[(geom(f),f['properties'],f) for f in load('uasfm.geojson')['features']]
uas=uas_all
uas=[x for x in uas if x[0].intersection(city).area>0.01]
air=[(geom(f),f['properties'],f) for f in load('airspace.geojson')['features']]
surf=[x for x in air if x[1]['LOWER_CODE']=='SFC' and x[1]['LOWER_VAL']==0 and x[1]['CLASS'] in ['B','C','D','E']]
u=unary_union([g for g,p,f in uas]);s=unary_union([g for g,p,f in surf])
mi2=1609.344**2
def ar(g):return g.area/mi2
def metric(g):return {'sq_mi':ar(g.intersection(land)),'pct_land':100*g.intersection(land).area/land.area,'sq_mi_total_boundary':ar(g.intersection(city))}
out={'city_total_sq_mi':ar(city),'city_water_sq_mi':ar(water),'city_land_sq_mi':ar(land),'uasfm_union':metric(u),'surface_airspace_union':metric(s),'grid_outside_surface':metric(u.difference(s)),'surface_outside_grid':metric(s.difference(u)),'intersecting_cells':len(uas)}
out['airport']={}
for a in ['LRF','ORK','LIT']:
 subset=[g for g,p,f in uas if a in [p.get(f'APT{i}_FAAID') for i in range(1,6)]]
 out['airport'][a]={**metric(unary_union(subset)),'cells':len(subset),'laanc_attributes':sorted(set(str(p.get(f'APT{i}_LAANC')) for g,p,f in uas for i in range(1,6) if p.get(f'APT{i}_FAAID')==a))}
# Exclusive airport-combination areas: actual atomic partitions, not airport sum.
parts=[(land,frozenset())]
for a in ['LRF','ORK','LIT']:
 ag=unary_union([g for g,p,f in uas if a in [p.get(f'APT{i}_FAAID') for i in range(1,6)]])
 new=[]
 for g,tags in parts:
  yes=g.intersection(ag);no=g.difference(ag)
  if yes.area>.01:new.append((yes,tags|{a}))
  if no.area>.01:new.append((no,tags))
 parts=new
out['exclusive_airport']={'+'.join(sorted(t)) or 'Outside UASFM':metric(g) for g,t in parts}
out['ceilings']={};assigned=Point().buffer(0)
for c in sorted(set(p['CEILING'] for g,p,f in uas)):
 cg=unary_union([g for g,p,f in uas if p['CEILING']==c]).difference(assigned)
 out['ceilings'][str(c)]=metric(cg);assigned=unary_union([assigned,cg])
out['airport_ceiling']={}
for a in ['LRF','ORK','LIT']:
 out['airport_ceiling'][a]={};assigned=Point().buffer(0)
 for c in sorted(set(p['CEILING'] for g,p,f in uas)):
  cg=unary_union([g for g,p,f in uas if p['CEILING']==c and a in [p.get(f'APT{i}_FAAID') for i in range(1,6)]]).difference(assigned)
  if cg.intersection(land).area>.01:out['airport_ceiling'][a][str(c)]=metric(cg)
  assigned=unary_union([assigned,cg])
out['surface_by_airport']={a:metric(unary_union([g for g,p,f in surf if p['IDENT']==a])) for a in ['LRF','ORK','LIT']}
lon,lat=-92.208861322158,34.833337827083945
spd=transform(proj,Point(lon,lat))
geod=Geod(ellps='WGS84');coords=[geod.fwd(lon,lat,az,3*1609.344)[:2] for az in range(0,361)]
from shapely.geometry import Polygon
radius=transform(proj,Polygon(coords))
u_all=unary_union([g for g,p,f in uas_all])
out['planning_radius']={'center':[lon,lat],'radius_statute_miles':3,'total_sq_mi':ar(radius),'city_land':metric(radius),'surface_sq_mi':ar(radius.intersection(s)),'surface_pct_circle':100*radius.intersection(s).area/radius.area,'uasfm_sq_mi':ar(radius.intersection(u_all)),'uasfm_pct_circle':100*radius.intersection(u_all).area/radius.area}
out['spd_cells']=[p for g,p,f in uas if g.covers(spd)]
out['spd_airspace']=[p for g,p,f in air if g.covers(spd)]
out['metadata_dates']={k:{a:datetime.datetime.fromtimestamp(t/1000,datetime.timezone.utc).isoformat() for a,t in load(k+'_metadata.json').get('editingInfo',{}).items()} for k in ['city','uasfm','airspace']}
(O/'analysis_results.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
with (O/'area_summary.csv').open('w',newline='',encoding='utf-8') as h:
 w=csv.writer(h);w.writerow(['category','land_sq_mi','percent_city_land'])
 w.writerow(['Sherwood land',ar(land),100]);w.writerow(['Sherwood water',ar(water),'']);w.writerow(['Sherwood total boundary',ar(city),''])
 for key in ['uasfm_union','surface_airspace_union','grid_outside_surface','surface_outside_grid']:w.writerow([key,out[key]['sq_mi'],out[key]['pct_land']])
 for key in ['airport','exclusive_airport','ceilings','surface_by_airport']:
  for a,d in out[key].items():w.writerow([key+': '+a,d['sq_mi'],d['pct_land']])
 for a,cs in out['airport_ceiling'].items():
  for c,d in cs.items():w.writerow(['airport ceiling: '+a+' / '+c+' ft AGL',d['sq_mi'],d['pct_land']])
features=[]
def add(g,p):features.append({'type':'Feature','geometry':mapping(transform(inv,g)),'properties':p})
add(city,{'layer':'Sherwood boundary'});add(land,{'layer':'Sherwood land minus Census water'});add(radius,{'layer':'Proposed 3-statute-mile planning radius','authorized_coverage':False});add(spd,{'layer':'SPD / BRINC dock site','site_verified':True,'pin_source':'April 14 2026 site survey p3; installation at police HQ confirmed August 19 summary p2; as-built coordinates not independently surveyed'})
for g,p,f in uas:add(g,{**p,'layer':'UASFM intersecting city'})
for g,p,f in surf:add(g,{**p,'layer':'FAA surface airspace'})
(O/'sherwood_overlay.geojson').write_text(json.dumps({'type':'FeatureCollection','features':features}),encoding='utf-8')
print(json.dumps({k:v for k,v in out.items() if k not in ['spd_cells','spd_airspace','airport_ceiling']},indent=2));print('SPD cells',[(p['CEILING'],p['APT1_FAAID'],p['APT2_FAAID']) for p in out['spd_cells']]);print('SPD airspace',[(p['NAME'],p['LOWER_VAL'],p['LOWER_CODE']) for p in out['spd_airspace']])
