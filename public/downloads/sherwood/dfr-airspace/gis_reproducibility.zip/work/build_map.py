import sys
# Requires shapely, pyproj, geopandas, matplotlib, reportlab and requests.
import json,pathlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as Patch,Patch as LegendPatch
from matplotlib.lines import Line2D
from shapely.geometry import shape
from shapely.ops import transform,unary_union
from pyproj import Transformer
W=pathlib.Path('work');O=pathlib.Path('outputs');d=json.loads((O/'analysis_results.json').read_text())
t=Transformer.from_crs(4326,5070,always_xy=True).transform
features=json.loads((O/'sherwood_overlay.geojson').read_text())['features']
city=transform(t,shape(features[0]['geometry']));radius=transform(t,shape(features[2]['geometry']));spd=transform(t,shape(features[3]['geometry']))
uas=[(transform(t,shape(f['geometry'])),f['properties']) for f in features if f['properties']['layer']=='UASFM intersecting city']
air=[(transform(t,shape(f['geometry'])),f['properties']) for f in features if f['properties']['layer']=='FAA surface airspace']
def polygons(g):
 if g.geom_type=='Polygon':yield g
 elif hasattr(g,'geoms'):
  for x in g.geoms:yield from polygons(x)
def draw(ax,g,face='none',edge='#222',lw=1,alpha=1,z=1,ls='-'):
 for p in polygons(g):
  ax.add_patch(Patch(list(p.exterior.coords),facecolor=face,edgecolor=edge,linewidth=lw,alpha=alpha,zorder=z,linestyle=ls))
  if face!='none':
   for ring in p.interiors:ax.add_patch(Patch(list(ring.coords),facecolor='#f3f5f7',edgecolor=edge,linewidth=.3,zorder=z+.1))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10})
fig=plt.figure(figsize=(16,10),facecolor='white')
fig.text(.045,.95,'SHERWOOD DFR | airspace and planning coverage',fontsize=23,fontweight='bold',color='#132a40')
fig.text(.045,.912,'Actual city and FAA geometries • October 6, 2026 snapshot • ARAP analysis',fontsize=12,color='#506477')
axes=[fig.add_axes([.045,.22,.435,.64]),fig.add_axes([.52,.22,.435,.64])]
b=unary_union([city,radius]).bounds;pad=600
for ax in axes:
 ax.set_facecolor('#f3f5f7');ax.set_xlim(b[0]-pad,b[2]+pad);ax.set_ylim(b[1]-pad,b[3]+pad);ax.set_aspect('equal');ax.set_xticks([]);ax.set_yticks([])
 for spine in ax.spines.values():spine.set_color('#c8d2dc')
 draw(ax,city,face='#e2e7ec',edge='none')
 draw(ax,radius,edge='#ad6e00',lw=2,ls='--',z=6)
 draw(ax,city,edge='#172f43',lw=2.4,z=7)
 ax.plot(spd.x,spd.y,marker='*',markersize=14,color='#122a41',markeredgecolor='white',zorder=9)
 ax.annotate('SPD / BRINC dock site',xy=(spd.x,spd.y),xytext=(spd.x-1600,spd.y-900),fontsize=8.5,fontweight='bold',bbox={'facecolor':'white','edgecolor':'none','alpha':.9,'pad':3},arrowprops={'arrowstyle':'-','color':'#122a41'},zorder=10)
 x=b[0]+450;y=b[3]-500;ax.plot([x,x+1609.344],[y,y],color='#142d42',lw=3,zorder=12);ax.text(x+804.672,y+190,'1 statute mile',ha='center',fontsize=8,color='#142d42',zorder=12,bbox={'facecolor':'white','edgecolor':'none','alpha':.7,'pad':1})
 ax.annotate('N',xy=(b[2]-450,b[3]-200),xytext=(b[2]-450,b[3]-1100),ha='center',va='center',fontsize=11,fontweight='bold',arrowprops={'arrowstyle':'-|>','lw':1.5,'color':'#142d42'},zorder=12)
for g,p in uas:
 a=p['APT1_FAAID'];c=p['CEILING'];color='#edafa6' if c==0 else ('#9dcfc7' if a=='LRF' else '#bbb5e0')
 draw(axes[0],g,face=color,edge='#ffffff',lw=.7,alpha=.84,z=3)
 pt=g.representative_point();axes[0].text(pt.x,pt.y,f'{a}\n{c}',ha='center',va='center',fontsize=6.6,color='#24384b',linespacing=1.0,zorder=5)
for a in ['LRF','LIT']:
 g=unary_union([g for g,p in air if p['IDENT']==a]);draw(axes[1],g,face=('#a6c9e3' if a=='LRF' else '#cbc1e5'),edge=('#367aaf' if a=='LRF' else '#7a60b1'),lw=1.2,alpha=.8,z=3)
axes[1].text(spd.x+2100,spd.y+5400,'LRF\nClass D / surface E2\n(shared footprint)',fontsize=10,ha='center',color='#184d75',zorder=5,bbox={'facecolor':'white','edgecolor':'none','alpha':.65,'pad':3})
axes[1].text(spd.x-1000,spd.y-3550,'LIT\nClass C surface area',fontsize=9,ha='center',color='#654996',zorder=5,bbox={'facecolor':'white','edgecolor':'none','alpha':.7,'pad':3})
axes[0].set_title('UAS FACILITY MAP CELLS\n75.7% of city land • 15.707 sq mi • 85 cells',loc='left',fontsize=12,fontweight='bold',pad=12)
axes[1].set_title('FAA SURFACE AIRSPACE FOOTPRINT\n65.2% of city land • 13.524 sq mi • union, counted once',loc='left',fontsize=12,fontweight='bold',pad=12)
axes[0].legend(handles=[LegendPatch(facecolor='#edafa6',label='LRF: CEILING 0 ft AGL'),LegendPatch(facecolor='#9dcfc7',label='LRF: CEILING 400 ft AGL'),LegendPatch(facecolor='#bbb5e0',label='LIT: CEILING 400 ft AGL')],loc='lower left',fontsize=8,framealpha=.96)
axes[1].legend(handles=[LegendPatch(facecolor='#a6c9e3',label='LRF: D / E2, activation per NOTAM'),LegendPatch(facecolor='#cbc1e5',label='LIT: surface Class C'),Line2D([0],[0],color='#172f43',lw=2,label='Sherwood city limits'),Line2D([0],[0],color='#ad6e00',lw=2,ls='--',label='Proposed 3-mile planning radius')],loc='lower left',fontsize=8,framealpha=.96)
fig.text(.045,.165,'GRID VALUES ARE INFORMATIONAL. They do not authorize flight.',fontsize=13,fontweight='bold',color='#913d35')
fig.text(.045,.125,'The 3-statute-mile circle covers 75.3% of city land. It depicts proposed response planning, not FAA-authorized coverage.\nNo ORK-attributed UASFM cells or ORK surface polygons intersect Sherwood in the queried FAA layers.',fontsize=11,color='#324e63',linespacing=1.5)
fig.text(.045,.065,'Sources: City_Boundary layer in Sherwood Master Map; FAA UAS Facility Map Data and Class Airspace layers; Census TIGER/Line 2025 water.\nLand denominator: city boundary minus mapped Census water (20.744 sq mi). Site: April 14 survey coordinate, installation confirmed August 19.\nClass E5 floors at 700/1,200 ft AGL and elevated Class C shelves are excluded from surface coverage. Map is analytical, not for navigation.',fontsize=9,color='#5c6e7f',linespacing=1.45)
fig.savefig(O/'sherwood_dfr_map.png',dpi=190,facecolor='white');plt.close(fig)
print('Map saved')
