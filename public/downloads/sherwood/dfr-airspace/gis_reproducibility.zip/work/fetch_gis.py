import sys
# Requires shapely, pyproj, geopandas, matplotlib, reportlab and requests.
import requests,json,pathlib,datetime
from shapely.geometry import shape
from shapely.ops import unary_union
W=pathlib.Path('work'); O=pathlib.Path('outputs'); O.mkdir(exist_ok=True)
def get(url,params=None):
 r=requests.get(url,params=params,timeout=120);r.raise_for_status();d=r.json()
 if 'error' in d: raise RuntimeError(d['error'])
 return d
def save(name,d):
 (W/name).write_text(json.dumps(d),encoding='utf-8');return d
city='https://services9.arcgis.com/TYC03dQ8ZCOCi5CP/arcgis/rest/services/City_Boundary/FeatureServer/0'
faa='https://services6.arcgis.com/ssFJjBXIUyZDrSYZ/arcgis/rest/services/'
urls={'city':city,'uasfm':faa+'FAA_UAS_FacilityMap_Data/FeatureServer/0','airspace':faa+'Class_Airspace/FeatureServer/0'}
for k,u in urls.items(): save(k+'_metadata.json',get(u,{'f':'json'}))
c=save('city.geojson',get(city+'/query',{'f':'geojson','where':'1=1','outFields':'*','outSR':4326}))
g=unary_union([shape(f['geometry']) for f in c['features']]);print('city features',len(c['features']),'bounds',g.bounds)
b=g.bounds;env=','.join(map(str,[b[0]-.06,b[1]-.06,b[2]+.06,b[3]+.06]))
for k in ['uasfm','airspace']:
 p={'f':'json','where':'1=1','geometry':env,'geometryType':'esriGeometryEnvelope','inSR':4326,'spatialRel':'esriSpatialRelIntersects','returnIdsOnly':'true'}
 ids=get(urls[k]+'/query',p)['objectIds'] or [];features=[]
 for i in range(0,len(ids),150):
  d=get(urls[k]+'/query',{'f':'geojson','objectIds':','.join(map(str,ids[i:i+150])),'outFields':'*','outSR':4326});features+=d['features']
 save(k+'.geojson',{'type':'FeatureCollection','features':features});print(k,'ids',len(ids),'features',len(features))
 if k=='airspace':
  for f in features: print(f['properties'])
 else:
  print('airport tags',sorted(set(str(f['properties'].get('APT'+str(i)+'_FAAID')) for f in features for i in range(1,6))))
geo=save('spd_geocode.json',get('https://geocode.arcgis.com/arcgis/rest/services/World/GeocodeServer/findAddressCandidates',{'f':'json','SingleLine':'2201 E Kiehl Ave, Sherwood, AR 72120','outFields':'*'}))
print('geocode',[(x['address'],x['score'],x['location']) for x in geo['candidates'][:2]])
u='https://www2.census.gov/geo/tiger/TIGER2025/AREAWATER/tl_2025_05119_areawater.zip'
r=requests.get(u,timeout=120);r.raise_for_status();(W/'water.zip').write_bytes(r.content);print('water bytes',len(r.content))
save('retrieval.json',{'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'urls':urls,'water_url':u,'query_envelope':env})
