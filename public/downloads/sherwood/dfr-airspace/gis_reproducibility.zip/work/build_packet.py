import sys,os
# Requires shapely, pyproj, geopandas, matplotlib, reportlab and requests.;os.environ['MPLCONFIGDIR']=str(__import__('pathlib').Path('work/mplconfig').resolve())
import json,pathlib
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor,white
from reportlab.platypus import Paragraph,Table,TableStyle
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
O=pathlib.Path('outputs');d=json.loads((O/'analysis_results.json').read_text());c=canvas.Canvas(str(O/'sherwood_dfr_analysis.pdf'),pagesize=(1152,720))
c.setTitle('Sherwood DFR: airspace, planning coverage and FAA authority');c.setAuthor('Arkansas Accountability Project')
c.drawImage(str(O/'sherwood_dfr_map.png'),0,0,width=1152,height=720);c.showPage();c.setPageSize((792,612))
normal=ParagraphStyle('normal',fontName='Helvetica',fontSize=10.2,leading=14,textColor=HexColor('#20394e'))
small=ParagraphStyle('small',parent=normal,fontSize=8.8,leading=11.5)
heading=ParagraphStyle('heading',parent=normal,fontName='Helvetica-Bold',fontSize=13,leading=17)
def start(title,page):
 c.setFillColor(HexColor('#132a40'));c.setFont('Helvetica-Bold',20);c.drawString(42,568,title)
 c.setFont('Helvetica',9);c.setFillColor(HexColor('#5a7183'));c.drawString(42,548,'ARAP | October 6, 2026 | Geometry analysis and CITY-2026-150 records')
 c.setFont('Helvetica',8);c.drawString(42,24,'UASFM values are informational and do not authorize flight. Planning circle is not authorized coverage.');c.drawRightString(750,24,str(page)+' / 4')
 return 519
def para(text,y,style=normal,width=708):
 p=Paragraph(text,style);w,h=p.wrap(width,y-45);p.drawOn(c,42,y-h);return y-h-9
def table(rows,y,widths):
 data=[[Paragraph(str(x),small) for x in row] for row in rows];t=Table(data,colWidths=widths,hAlign='LEFT');t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),HexColor('#e5edf3')),('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,0),.7,HexColor('#8fa4b5')),('LINEBELOW',(0,1),(-1,-1),.25,HexColor('#d6e0e7')),('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]));w,h=t.wrap(708,500);t.drawOn(c,42,y-h);return y-h-14
y=start('Measured footprint: city land and FAA overlays',2)
y=table([['Measure','Land sq mi','City land'],['Sherwood land (boundary minus Census water)','20.744','100.0%'],['Mapped surface-controlled-airspace union','13.524','65.2%'],['UASFM polygon union','15.707','75.7%'],['UASFM area outside surface-airspace footprint','2.182','10.5%'],['Proposed 3-statute-mile circle intersecting city land','15.616','75.3%']],y,[466,120,122])
y=para('Total municipal polygon: 21.155 sq mi; mapped water: 0.410 sq mi. All reported city percentages use 20.744 sq mi of estimated land. These are horizontal mapped footprints, not a live determination of active airspace or a flight authorization.',y,small)
y=table([['Airport / UASFM CEILING','Land sq mi','City land'],['LRF (Little Rock AFB) / 0 ft AGL','5.134','24.7%'],['LRF / 400 ft AGL','8.390','40.4%'],['LIT (Little Rock) / 400 ft AGL','2.182','10.5%'],['ORK (North Little Rock) / no attributed intersection','0.000','0.0%']],y,[466,120,122])
y=para('<b>85 intersecting cells:</b> 69 LRF, 16 LIT; 27 zero-ceiling and 58 400-ft cells. Attribution uses every APTn_FAAID field. Airport and ceiling unions prevent double counting; no positive-area airport overlap occurs within this city snapshot.',y,small)
y=para('<b>Actual surface airspace:</b> LRF D/E2 union 12.197 sq mi (58.8%); LIT surface C 1.327 sq mi (6.4%). LRF D and E2 share one footprint and are counted once, with activation per NOTAM. Elevated Class C shelves and Class E5 floors of 700/1,200 ft AGL are excluded. ORK absence from these layers does not remove other operating obligations.',y,small)
assert y>38,y
c.showPage()
y=start('FAA authority: existing waiver, retained conditions',3)
for title,body in [
 ('A produced Part 91 certificate provides conditional authority','Certificate 91.113-2026-00585, signed May 14, 2026, lists May 13, 2026-May 31, 2030 as its term, subject to cancellation. Page 2 says it also serves as an airspace authorization under its provisions, excluding prohibited/restricted airspace. The production does not establish subsequent amendment/cancellation status or actual mission compliance.'),
 ('A 400-ft cell does not permit 400-ft routine controlled-airspace BVLOS','Page 3, provisions 10-12: controlled-airspace BVLOS is limited to at/below 200 ft AGL or below the UASFM altitude, whichever is lower. A zero-ft grid supplies no positive-altitude access under those blanket provisions. The obstacle-related alternative is in Class G and is capped at 400 ft; it is not a general 300-ft allowance everywhere.'),
 ('Additional authority follows the certificate, not a talking-point shortcut','Provision 12 requires CAPS/CADZ authorization above grid heights, in controlled airspace where UASFMs are inapplicable, and in other listed cases. The Talking Paper describes exceeding grid values through tower communication; the certificate does not establish that a phone call alone replaces required written additional authority. Provision 32 addresses SGI approval when emergency operations need to exceed the approved envelope.'),
 ('Automated launch still has to satisfy the approved operation','Pages 5-6 retain remote-PIC responsibilities, current-grid review, lost-link return-to-home limits, air-traffic deconfliction and ADS-B detection requirements. Preflight checklist provision 30 includes an urgent emergency-management qualification. CAD/Flock/duress launch options in the Talking Paper describe capability/planning; they do not establish enabled triggers or approval for unattended launch.'),
 ('LAANC and BVLOS are separate questions','For ordinary Part 107 operations, LAANC may issue qualifying airspace authorization at participating facilities; it does not approve BVLOS. LRF/LIT grid attributes flag LAANC participation, but that does not show Sherwood uses LAANC for Part 91 flights. FAA directs Part 107 waiver users seeking controlled-airspace access to FAADroneZone; this Part 91 certificate specifies CAPS/CADZ for its additional-authority cases.')]:
 y=para(title,y,heading);y=para(body,y)
assert y>38,y
c.showPage()
y=start('Site, planning circle, method and sources',4)
y=para('<b>Documented site.</b> April 14 BRINC site survey, p. 3: Police Headquarters, 2201 E Kiehl Ave, roof station at 34.833337827083945, -92.208861322158. Signed August 19 installation summary, pp. 2 and 7, confirms that site/address. Pin uses the surveyed coordinate, not an independently measured as-built location.',y)
y=para('<b>Planning claim comparison.</b> Talking Paper describes a roughly three-mile response radius and estimates 90-95% city coverage. A 3-statute-mile geodesic circle on the current boundary covers 75.3% of city land. This measures land area, not residents or calls; the circle is not an authorization boundary or a certificate-imposed distance limit. Of the entire 28.273-sq-mi circle, 54.0% intersects surface airspace and 66.5% intersects UASFM polygons (different denominator, includes water/neighbors).',y)
y=para('<b>Launch-point discrepancy.</b> The survey calls the site Class D, but current FAA geometry places its coordinate about 645 m outside the nearest surface footprint and essentially on a UASFM edge (about 0.13 m outside the mathematical grid). Address geocoding shifts it about 29 m into a 400-ft LRF cell. Reconcile final coordinates, charts and NOTAMs before operational configuration; do not infer launch-point authority from this regional map.',y)
y=para('<b>Method.</b> Query actual geometries, outSR 4326; project to EPSG:5070 equal-area meters. Subtract unioned 2025 Census mapped water from city boundary. Union airport, ceiling and surface polygons before intersection; assign any ceiling overlap to the lowest CEILING. Surface selection requires LOWER_VAL=0 and LOWER_CODE=SFC. Geodesic radius: 3 x 1609.344 m, one-degree azimuth samples. Raw features, metadata, reproducible scripts, CSV, GeoJSON and full source note accompany the outputs.',y)
y=para('Primary sources',y,heading)
links=[('City Master Map and City_Boundary','https://www.arcgis.com/home/item.html?id=2849b15e116b40f2bf0c48f4ebd12306'),('FAA UASFM layer','https://services6.arcgis.com/ssFJjBXIUyZDrSYZ/arcgis/rest/services/FAA_UAS_FacilityMap_Data/FeatureServer/0'),('FAA Class Airspace layer','https://services6.arcgis.com/ssFJjBXIUyZDrSYZ/arcgis/rest/services/Class_Airspace/FeatureServer/0'),('Census water: Pulaski County 2025','https://www2.census.gov/geo/tiger/TIGER2025/AREAWATER/tl_2025_05119_areawater.zip'),('FAA UASFM caveat','https://www.faa.gov/uas/commercial_operators/uas_facility_maps/faq'),('FAA LAANC / DroneZone guidance','https://www.faa.gov/uas/getting_started/where_can_i_fly/airspace_restrictions/flying_near_airports')]
y=para(' | '.join(f'<link href="{u}" color="#235e90">{label}</link>' for label,u in links),y,small)
y=para('CITY-2026-150 records: BRINC Talking Paper.docx; April 14 site survey pp. 3-4; August 19 installation summary pp. 2, 7-9; May 14 FAA certificate, all six pages. Certificate provisions take precedence over the Talking Paper. Its incorporated application has not been identified in this production.',y,small)
y=para('<b>Metadata corrections.</b> Supplied experience 58bae0a8445d49c39f44a1a4654eb961 is City of Sherwood-Master Map, not an FAA viewer. The live city service reports February 25, 2026 geometry edit, distinct from the March 3 catalog update described in the request. FAA grid edit: October 6, 2026 01:56 UTC; airspace data edit: September 28, 2026 13:50 UTC. Retain UTC metadata instead of implying local-day dates.',y,small)
assert y>38,y
c.save();print('Four-page PDF saved')
